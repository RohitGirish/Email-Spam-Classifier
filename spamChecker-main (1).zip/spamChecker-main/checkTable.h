#ifndef CHECKTABLE_H
#define CHECKTABLE_H

#include "pa1.h"

int checkTable(char *str,linkedListNode_t** hashtbl);



#endif
