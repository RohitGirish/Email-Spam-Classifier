#ifndef RETRIEVELINKEDLIST_H
#define RETRIEVELINKEDLIST_H

linkedListNode_t *retrieveLinkedList(linkedListNode_t** hashtbl, char* string);

#endif
