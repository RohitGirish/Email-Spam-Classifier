#ifndef POPULATETABLE_H
#define POPULATETABLE_H	

#include "pa1.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void populateTable(linkedListNode_t** hashtbl, FILE* dataFile);

#endif
