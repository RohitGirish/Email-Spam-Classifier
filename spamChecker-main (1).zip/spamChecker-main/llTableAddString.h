#ifndef LLTABLEADDSTRING_H
#define LLTABLEADDSTRING_H


void llTableAddString(linkedListNode_t** hashtbl, char* string);

#endif
