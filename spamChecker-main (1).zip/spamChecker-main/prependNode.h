#ifndef PREPENDNODE_H
#define PREPENDNODE_H


void prependNode(linkedListNode_t** head, char* str);


#endif
