#ifndef HASH_H
#define HASH_H

unsigned int hash(char* str);

#endif
